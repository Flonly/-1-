package book;

import java.util.Vector;

enum BookType{
    SCIENCE, MEDICINE, LITERATURE, FOODCOOKING, MAGAZINE;
    
} //图书类型枚举
enum Press{
    清华大学出版社, 北京大学出版社, 电子工业出版社, 机械工业出版社, 杂志期刊主办商;
} //出版社类型枚举
enum BorrowType{
    办理借阅, 不能借阅;
}//图书状态
enum Sex{
    男, 女;
} //性别枚举
class Book{  //图书类
    String bookName;
    Press press;
    BookType bookType;
    BorrowType borrowType;
    void printBookInfo(){
        System.out.println(this.bookName+" "+this.press+" "+this.borrowType+" "+this.bookType);
    }//打印图书信息
    Book(String bookName, String press, String bookType, String borrowType){
        this.bookName = bookName;
        switch(press){
            case "清华大学出版社":
                this.press = Press.清华大学出版社;
                break;
            case "北京大学出版社":
                this.press = Press.北京大学出版社;
                break;
            case "电子工业出版社":
                this.press = Press.电子工业出版社;
                break;
            case "机械工业出版社":
                this.press = Press.机械工业出版社;
                break;
            case "杂志期刊主办商":
                this.press = Press.杂志期刊主办商;
                break;
        }
        switch(bookType){//SCIENCE, MEDICINE, LITERATURE, FOODCOOKING, MAGAZINE;
            case "SCIENCE":
                this.bookType = BookType.SCIENCE;
                break;
            case "MEDICINE":
                this.bookType = BookType.MEDICINE;
                break;
            case "LITERATURE":
                this.bookType = BookType.LITERATURE;
                break;
            case "FOODCOOKING":
                this.bookType = BookType.FOODCOOKING;
                break;
            case "MAGAZINE":
                this.bookType = BookType.MAGAZINE;
                break;
        }
        switch(borrowType){
            case "办理借阅":
                this.borrowType = BorrowType.办理借阅;
                break;
            case"不能借阅":
                this.borrowType = BorrowType.不能借阅;
                break;
        }
}
static class Reader{  //读者类
    String readerName;
    Sex sex;
    Book[] books;
    void printBorrowInfo(){
        System.out.println("姓名："+this.readerName+" 性别："+this.sex+" 借阅信息如下：");
        System.out.println("图书名称      出版社       状态    类型");
        System.out.println("============================================");
        for(int i = 0; i < books.length; i++) books[i].printBookInfo();
    }  //打印该读者的借阅信息


    //构造方法 采用vector自动插入图书信息 实现一劳永逸
    Reader(String readerName, String sex, Vector<Book> books1){
        this.readerName = readerName;
        switch(sex){
            case "男":
                this.sex = Sex.男;
                break;
            case "女":
                this.sex = Sex.女;
                break;
        }

        this.books = new Book[books1.size()];

        for(int i = 0; i < books1.size(); i++){
            this.books[i] = books1.elementAt(i);
        }

    }
}

}
public class LibraryDemo {
    public static void main (String[] args) {
        Book b1 = new Book("数据库原理", "清华大学出版社", "SCIENCE","办理借阅");
        Book b2 = new Book("医学与美容", "北京大学出版社", "MEDICINE","办理借阅");
        Book b3 = new Book("平凡的世界", "电子工业出版社", "LITERATURE","办理借阅");
        Book b4 = new Book("饮食与健康", "机械工业出版社", "FOODCOOKING","办理借阅");
        Book b5 = new Book("计算机基础", "北京大学出版社", "SCIENCE","办理借阅");
        Book b6 = new Book("计算机科学", "杂志期刊主办商", "MAGAZINE","不能借阅");

        Vector books1 = new Vector<Book>();
        books1.add(b1);
        books1.add(b2);
        books1.add(b3);

        Vector books2 = new Vector<Book>();
        books2.add(b4);
        books2.add(b5);
        books2.add(b6);


        Book.Reader r1 = new Book.Reader("李红", "女", books1);
        r1.printBorrowInfo();

        System.out.println();
        System.out.println("*************************************");
        System.out.println();

        Book.Reader r2 = new Book.Reader("王伟", "男", books2);
        r2.printBorrowInfo();
    }
}

