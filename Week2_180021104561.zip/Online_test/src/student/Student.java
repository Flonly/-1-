package student;

import java.util.Vector;

public class Student { //学生类
    String name;
    String sex;
    Subject[] subjects;

    //构造方法 采用vector 能自动录入所有成绩
    Student(String s_name, String sex, Vector<Subject> sj){
        this.name = s_name;
        this.sex = sex;
        subjects = new Subject[sj.size()];//科目数量由size决定 无需给定数字

        for(int i = 0; i < sj.size(); i++){
            subjects[i] = sj.elementAt(i);
        }//自动录入 给多少录多少
    }

    public Student() {

    }


    //成员内部类：课程类
    class Subject {
        String subjectName;//课名
        SubjectType st = new SubjectType();//课程分数系数
        int atten;
        int assign;
        int lab;
        int finalExam;

        //subject构造方法
        Subject(String name, String type, int atten, int assign, int lab, int finalExam){
            this.subjectName = name;
            st.type = type;
            st.setRatio();//补全成绩系数
            this.atten = atten;
            this.assign = assign;
            this.lab = lab;
            this.finalExam = finalExam;
        }
    }

    static class SubjectType {
        String type;
        double attenRatio;//出勤系数
        static final double assignRatio = 0.1;//作业系数
        static final double labRatio = 0.1;//实验系数
        double finalRatio;//期末系数

        //设置当前科目的成绩系数
        void setRatio() {
            if (this.type.equals("考试")) {
                this.attenRatio = 0.1;
                this.finalRatio = 0.7;
            } else if (this.type.equals("考查")) {
                this.attenRatio = 0.2;
                this.finalRatio = 0.6;
            }

        }

    }

    void printInfo() {
        class calcScore { //局部内部类
            //用于计算总分
            int calcTotal(Subject sb) {
                return (int) (sb.atten * sb.st.attenRatio + sb.assign * sb.st.assignRatio + sb.lab * sb.st.labRatio + sb.finalExam * sb.st.finalRatio);
            }
        }
        calcScore cc = new calcScore();

        System.out.println("姓名："+this.name+" 性别："+this.sex);
        System.out.println("课程 性质 出勤 作业 实验 期末 总分");
        System.out.println("==================================");


            for(int i = 0; i < this.subjects.length; i++)
            System.out.println(this.subjects[i].subjectName+" "+this.subjects[i].st.type+" "+
                    this.subjects[i].atten+"   "+ this.subjects[i].assign+ "   "+
                    this.subjects[i].lab +"   "+this.subjects[i].finalExam+  "   "+
                    cc.calcTotal(this.subjects[i]));

    }

    public static void main(String[] args) {


        Student.Subject sj11 = new Student().new Subject("java", "考查", 90, 85, 75, 80);
        Student.Subject sj13 = new Student().new Subject("SQL", "考试", 80, 90, 82, 75);
        Student.Subject sj12 = new Student().new Subject("J2EE", "考查", 78, 70, 65, 70);
        Vector sj1 = new Vector<Subject>();
        sj1.add(sj11);
        sj1.add(sj12);
        sj1.add(sj13);
        Student s1 = new Student("张三", "男", sj1);
        s1.printInfo();

        System.out.println();
        System.out.println("************************");
        System.out.println();


        Student.Subject sj21 = new Student().new Subject("java", "考查", 86, 67, 71, 70);
        Student.Subject sj22 = new Student().new Subject("J2EE", "考查", 88, 74, 68, 80);
        Student.Subject sj23 = new Student().new Subject("SQL", "考试", 77, 70, 85, 66);
        Vector sj2 = new Vector<Subject>();
        sj2.add(sj21);
        sj2.add(sj22);
        sj2.add(sj23);
        Student s2 = new Student("李四", "女", sj2);
        s2.printInfo();



    }
}

