package generics;

import java.util.*;

//定义小轿车类
class Car implements Comparable<Car>{
    String carCode; //车辆代号
    String brand; //品牌
    String mode;  //款式
    String color; //颜色
    int price;
    //写构造方法
    Car(String carCode, String brand, String mode, String color, int price){
        this.carCode = carCode;
        this.brand = brand;
        this.mode = mode;
        this.color = color;
        this.price = price;
    }
    public int compareTo(Car c){ //比较价格的方法
        return c.price - this.price;
    }
    public void printCarInfo(){ //打印方法
        System.out.println(this.carCode+"  "+this.brand+"  "+this.mode+"  "+this.color+"  "+this.price);
    }
}

class CarDealer{ //车行
    String dealerName; //车行名称
    ArrayList<Car> cars;
    //构造方法
    CarDealer(String dealerName,ArrayList<Car> cars){
        this.dealerName = dealerName;
        this.cars = cars;
    }
    public void printCarDealerInfo(){
        System.out.println(this.dealerName+"热销车辆");
        System.out.println("车号    品牌  款式  颜色  价格");
        System.out.println("=======================================");
        Iterator<Car> it = cars.iterator();
        while(it.hasNext()){
            it.next().printCarInfo();
        }
        System.out.println();
        System.out.println();

    }
}

class Customer{ //顾客
    String name;
    HashMap<String,Car> cars; //String是购买日期，Car是该顾客购买的车
    //构造方法
    Customer(String name, HashMap<String,Car> cars){
        this.name = name;
        this.cars = cars;
    }
    public void printInfo(){
        System.out.println("顾客 "+this.name+" 所买车：");
        System.out.println("车号    品牌  款式  颜色  价格    购车时间");
        System.out.println("============================================");

        Set keys = cars.keySet();
        for(Object key : keys){
            System.out.println(cars.get(key).carCode+"  "+cars.get(key).brand+"  "+cars.get(key).mode+"  "+
                    cars.get(key).color+"  "+cars.get(key).price+" "+key);
        }
        System.out.println();
        System.out.println();

    }
}


public class GenericsDemo {
    public static void main(String[] args) {
        //1-实例化三个Car对象
        Car c11 = new Car("CS4634", "丰田", "皇冠", "灰色", 210000);
        Car c12 = new Car("CS1678", "丰田", "佳美", "白色", 200000);
        Car c13 = new Car("CS7789", "丰田", "科罗拉", "蓝色", 180000);

        Car c21 = new Car("CS9234", "本田", "雅阁", "黑色", 220000);
        Car c22 = new Car("CS2344", "本田", "飞度", "红色", 170000);
        Car c23 = new Car("CS6577", "本田", "思域", "银色", 150000);

        Car c31 = new Car("CS7689", "别克", "君威", "银色", 250000);
        Car c32 = new Car("CS4356", "别克", "凯越", "黑色", 240000);
        Car c33 = new Car("CS8122", "别克", "阅朗", "红色", 230000);
        //2-实例化一个ArrayList泛型集合对象
        ArrayList<Car> cars1 = new ArrayList<Car>();
        ArrayList<Car> cars2 = new ArrayList<Car>();
        ArrayList<Car> cars3 = new ArrayList<Car>();
        //3-把以上三部车加入到这个ArrayList泛型集合里
        cars1.add(c11);
        cars1.add(c12);
        cars1.add(c13);

        cars2.add(c21);
        cars2.add(c22);
        cars2.add(c23);

        cars3.add(c31);
        cars3.add(c32);
        cars3.add(c33);
        //4-实例化一个CarDealer对象
        CarDealer cd1 = new CarDealer("丰田车行", cars1);
        CarDealer cd2 = new CarDealer("本田车行", cars2);
        CarDealer cd3 = new CarDealer("别克车行", cars3);
        //5-输出该CarDealer车行所热销的车
        cd1.printCarDealerInfo();
        cd2.printCarDealerInfo();
        cd3.printCarDealerInfo();
        //6-步骤1-5一共重复三次，分别输出三个车行所热销的车
          //见上
        //7-实例化一个HashMap<String,Car>集合对象
        HashMap<String,Car> mp1 = new HashMap<String, Car>();
        HashMap<String,Car> mp2 = new HashMap<String, Car>();
        //8-从上面的车行里挑两部车放进该集合里
        mp1.put("2020.1.1", c11);
        mp1.put("2020.2.2", c21);
        Customer cus1 = new Customer("李田所", mp1);

        mp2.put("2020.3.3", c22);
        mp2.put("2020.4.4", c33);
        Customer cus2 = new Customer("王道往", mp2);
        //9-输出该顾客购买日期和车
        cus1.printInfo();
        cus2.printInfo();
        //10-步骤7-9一共重复两次，分别输出两个顾客所购买的车的信息
          //见上
    }
}
