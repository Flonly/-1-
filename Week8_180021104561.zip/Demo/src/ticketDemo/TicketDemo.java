package ticketDemo;

import java.io.*;
import java.util.Vector;

//��Ӱ����
enum MovieType implements Serializable{
    love("����Ƭ"),
    comedy("ϲ��Ƭ"),
    action("����Ƭ"),
    science("�ƻ�Ƭ");
    String type;

    MovieType(String type){
        this.type = type;
    }

}

//��Ӱ
class Movie implements Serializable{
    String name;//��Ӱ��
    MovieType mt;//��Ӱ���

    Movie(String name, MovieType mt){
        this.name = name;
        this.mt = mt;
    }
}

//��Ӱ��ӳʱ���
class MovieSchedule implements Serializable{
    String theatre;//��ӳ��
    String time;//��ӳʱ��

    MovieSchedule(String theatre, String time){
        this.theatre = theatre;
        this.time = time;
    }
}

//��λ
class Seat implements Serializable{
    int row;//������
    int column;//������

    Seat(int row, int column){
        this.row = row;
        this.column = column;
    }
}

//��ӰƱ
class Ticket implements Serializable{
    Movie movie;
    MovieSchedule schedule;
    Seat seat;

    Ticket(Movie movie, MovieSchedule schedule, Seat seat){
        this.movie = movie;
        this.schedule = schedule;
        this.seat = seat;
    }

    public void printTicket() {//��ӡ��ӰƱ
        System.out.println(this.movie.name);
        System.out.println("����:  " + this.movie.mt.type);
        System.out.println("ʱ��:  " + this.schedule.time);
        System.out.println("��ӳ��: " + this.schedule.theatre);
        System.out.println("��λ:  " + this.seat.row + "�� " + this.seat.column + "��");
        System.out.println("*****************************************");
    }


}
public class TicketDemo {
    public static void main (String[] args) {
        try {
            //1�����Ӱ���Ͷ���
            MovieType type1 = MovieType.action;
            MovieType type2 = MovieType.comedy;
            MovieType type3 = MovieType.love;
            MovieType type4 = MovieType.science;

            //2�����Ӱ����
            Movie m1 = new Movie("��ʹ����", type1);
            Movie m2 = new Movie("�������׸�", type2);
            Movie m3 = new Movie("Сʱ��", type3);
            Movie m4 = new Movie("���˵���", type4);

            //3���쳡�ζ���
            MovieSchedule ms1 = new MovieSchedule("1����","2020.1.1--19:00~20:00");
            MovieSchedule ms2 = new MovieSchedule("2����","2020.2.2--20:15~22:00");
            MovieSchedule ms3 = new MovieSchedule("3����","2020.3.3--12:00~14:00");
            MovieSchedule ms4 = new MovieSchedule("4����","2020.4.4--15:00~17:00");

            //4������λ����
            Seat s1 = new Seat(1,1);
            Seat s2 = new Seat(2,2);
            Seat s3 = new Seat(3,3);
            Seat s4 = new Seat(4,4);

            //5�����ӰƱ����
            Vector<Ticket> v1 = new Vector<>();
            Ticket t1 = new Ticket(m1,ms1,s1);
            Ticket t2 = new Ticket(m2,ms2,s2);
            Ticket t3 = new Ticket(m3,ms3,s3);
            Ticket t4 = new Ticket(m4,ms4,s4);
            v1.add(t1);
            v1.add(t2);
            v1.add(t3);
            v1.add(t4);

            //6���л�д��dat

            //ʵ����һ��ͨ��file����
            File file = new File("text.dat");

            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(v1);

            oos.close();
            fos.close();

            //7�����л���ȡdat
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Vector<Ticket> v2=(Vector<Ticket>)ois.readObject();
            System.out.println("*****************************************");

            for(Ticket m:v2){
                m.printTicket();
            }

            ois.close();
            fis.close();

        }catch(Exception ex) {
            ex.printStackTrace();
        }
    }
}
